# Tableegh-Android-gps
Android project prepared for GitHub APK build.
